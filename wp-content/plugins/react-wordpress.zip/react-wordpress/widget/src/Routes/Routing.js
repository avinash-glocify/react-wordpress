import React from 'react';
import Product from '../Components/Products/index.jsx';

import {
  BrowserRouter as Router,
  Route,
} from "react-router-dom";

const routing = (
    <Router>
      <div>
        <Route path="/" component={Product}></Route >
      </div>
    </Router>
)
export default routing;
